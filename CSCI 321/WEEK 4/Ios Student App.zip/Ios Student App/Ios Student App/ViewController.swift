//
//  ViewController.swift
//  Ios Student App
//
//  Created by Mason Greig on 2/8/17.
//  Copyright © 2017 NIU Computer Science 321. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var classImage: UIImageView!
    
    @IBAction func classChoice(sender: UISegmentedControl) {
        let segmentChoice: Int = sender.selectedSegmentIndex
        switch segmentChoice {
        case 1:
            classImage.image = UIImage (named: "image_CSCI321_1")
        case 2:
            classImage.image = UIImage (named: "image_CSCI521_1")
        default:
            classImage.image = UIImage ( named: "KR6_9264-Class")
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

