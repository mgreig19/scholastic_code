//
//  ViewController.swift
//  App: GreigLocalNotification-v2
//
//  Purpose: This app displays a local notification on the users home screen when the button is pressed. The notification allows the user to chose from three different shopping options. Each option will take the user to the associated web page
//
//  Created by Mason Greig on 3/29/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit
import UserNotifications //imports notification framework

class ViewController: UIViewController, UNUserNotificationCenterDelegate{
    
    //variable to hold the website to be navigated to
    var webSite:String!
    
    //holds the current notification center in center
    let center = UNUserNotificationCenter.current()
    
    //button function which triggers the push notification
    @IBAction func triggerNotification(sender: UIButton) {
        
        //Creates notification request actions
        let response1 = UNNotificationAction(identifier: "response1", title: "Shop for Men", options: UNNotificationActionOptions.foreground)
        
        let response2 = UNNotificationAction(identifier: "response2", title: "Shop for Women", options: UNNotificationActionOptions.foreground)
        
        let response3 = UNNotificationAction(identifier: "response3", title: "Shop for Children", options: UNNotificationActionOptions.foreground)
        
        let category = UNNotificationCategory(identifier: "ffCategory", actions: [response1, response2, response3], intentIdentifiers: [], options: [])
        
        //sets the availble options to chose from, to the created choices listed above
        center.setNotificationCategories([category])
        
        //the displayed message which shows on the users device when a notification is sent
        let message = UNMutableNotificationContent()
        message.title = "Friends & Family Event!"
        message.subtitle = "Starts today online & in-stores."
        message.body = "50% off 5 regular-priced items. Use Code: Friends50"
        message.badge = 1
        message.categoryIdentifier = "ffCategory"
        
        //Create a seven second timer to trigger the notification
        let timerTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 7, repeats: false)
        
        //Create a request and issue notification
        let request = UNNotificationRequest(identifier: "timerDone", content: message, trigger: timerTrigger)
        UNUserNotificationCenter.current().add(request)

    }
    
    //prints the different options from which a user can chose from when the notification is selected and assigns the appropiate website to the variable webSite and calls the performSegue method for the segue ID Web View in order to pass the website string to the webview controllor
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        //creates different responses based on the response by the user in the notification center pop up
        switch response.actionIdentifier{
            case "response1":
                print("MEN")
                webSite = "http://www.gap.com/browse/subDivision.do?cid=5065&mlink=5058,12456145,visnav_M&clink=12456%20145"
                performSegue(withIdentifier: "Web View", sender: self)
            case "response2":
                print("Women")
                webSite = "http://www.gap.com/browse/subDivision.do?cid=5646&mlink=5058,12456145,visnav_W&clink=12456%20145"
                performSegue(withIdentifier: "Web View", sender: self)
            case "response3":
                print("Children")
                webSite = "http://www.gap.com/browse/subDivision.do?cid=6487&mlink=5058,12456145,visnav_Baby&clink=124%2056145"
                performSegue(withIdentifier: "Web View", sender: self)
            default:
                break
        }
        completionHandler()
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge], completionHandler: {didAllow, error in})
        // Do any additional setup after loading the view, typically from a nib.
        
        //Let the notification center be the delegate
        UNUserNotificationCenter.current().delegate = self
    }
    
    //function prepares the information to be sent to the WebViewController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "Web View") {
            let destUrlVc = segue.destination as! WebViewController
            destUrlVc.openWebPage = webSite
            }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

