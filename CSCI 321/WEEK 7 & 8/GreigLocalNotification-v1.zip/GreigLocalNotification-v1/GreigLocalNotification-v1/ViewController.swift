//
//  ViewController.swift
//  GreigLocalNotification-v1

//  Purpose: This applicaiton displays a push notification on the users device.
//
//  Created by Mason Greig on 3/24/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit
import UserNotifications
class ViewController: UIViewController{
    
    //Mark action
    @IBAction func triggerNotification(sender: UIButton) {
        
       
        //Builds the message to be displayed by the push notification
        let message = UNMutableNotificationContent()
        message.title = "Friends & Family Event!"
        message.subtitle = "Starts today online & in-stores."
        message.body = "50% off 5 regular-priced items. Use Code: Friends50"
        message.badge = 1
        
        //Create a seven second timer to trigger the notification
        let timerTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 7, repeats: false)
        
        //Create a request and issue notification
        let request = UNNotificationRequest(identifier: "timerDone", content: message, trigger: timerTrigger)
        UNUserNotificationCenter.current().add(request)

    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge], completionHandler: {didAllow, error in})
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

