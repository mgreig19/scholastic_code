//
//  AuthorViewController.swift
//  GreigLocalNotification-v1
//
//  Created by Mason Greig on 3/31/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit

class AuthorViewController: UIViewController {

    @IBOutlet weak var authorWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //sets variables to the included html files in the project and NSData objects of the file
        let path = Bundle.main.path(forResource: "/index2", ofType: "html")!
        let data: NSData = NSData(contentsOfFile: path)!
        let html = NSString(data: data as Data, encoding: String.Encoding.utf8.rawValue)
        //load the html files to the webview in the viewcontroller
        authorWebView.loadHTMLString(html as! String, baseURL: Bundle.main.bundleURL)
        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
