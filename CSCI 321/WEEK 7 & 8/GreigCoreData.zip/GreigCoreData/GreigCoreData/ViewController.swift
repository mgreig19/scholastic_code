//
//  ViewController.swift
//  GreigCoreData
//
//  Created by Mason Greig on 3/24/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        //Create a reference new user object and store in the User's Entity
        /*
        let newUser = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context)
         
         //Create a new user and store it in the context
         newUser.setValue("bgreig", forKey: "username")
         newUser.setValue("niu12345", forKey: "password")
 
        
        do{
            try context.save()
            print("Saved!")
        }
        catch{
            print("Error!")
            
        }
        */
        ///*
        
        //retrieve and display the entity attributes in the output console
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        request.returnsObjectsAsFaults = false
        var Name: [String] = []
        var Security: [String] = []
        do {
            let results = try context.fetch(request)
            if results.count > 0 {
                for item in results as! [NSManagedObject] {
                    if let userName = item.value(forKey: "username") as? String{
                        Name.append(userName)
                    }
                    if let passWord = item.value(forKey: "password") as? String{
                        Security.append(passWord)
                    }
                }
                
            }
            var itr = 0;
            for item in Name{
                print(item)
                print(Security[itr])
                itr += 1
            }
            
            print("Found \(results.count) users")
            // Do any additional setup after loading the view, typically from a nib.
        }
        catch {
            print("Fetched data eror!")
        }
        //*/
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

