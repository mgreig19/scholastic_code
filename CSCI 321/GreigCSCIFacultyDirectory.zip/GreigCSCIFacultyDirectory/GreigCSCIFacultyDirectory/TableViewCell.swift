//
//  TableViewCell.swift
//  GreigCSCIFacultyDirectory
//
//  Created by Mason Greig on 4/09/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit
//Holds attributes of the Faculty plist
class TableViewCell: UITableViewCell {
    
    //Mark outlets to hold the information to display the plist data
    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var cellTitle: UILabel!
    @IBOutlet weak var cellSubTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
