//
//  ResourceViewController.swift
//  GreigCSCIFacultyDirectory
//
//  Created by Mason Greig on 4/24/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit

class ResourceViewController: UIViewController {
    
   
    @IBOutlet weak var webView: UIWebView!
    
    var openWebPage:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //these statements decide whether of not to display a webpage in the web view or one of the resource pdf files
        
        //faculty pdf
        if ( openWebPage == "http://www.cs.niu.edu/faculty/facultyhours.shtml"){
            let pdfLoc = NSURL(fileURLWithPath:Bundle.main.path(forResource: "FacultyHours", ofType:"pdf")!)
            let request = NSURLRequest(url: pdfLoc as URL)
            self.webView.loadRequest(request as URLRequest)
        }
            //ta help hours pdf
        else if (openWebPage == "http://www.cs.niu.edu/faculty/tahours.shtml"){
            let pdfLoc = NSURL(fileURLWithPath:Bundle.main.path(forResource: "TAHours", ofType:"pdf")!)
            let request = NSURLRequest(url: pdfLoc as URL)
            self.webView.loadRequest(request as URLRequest)
        }
            //display faculty webpage or faculty hours or ta help web page if pdfs are not working
        else{//assign the url to a NSURL object myURL
            let myURL = NSURL(string: openWebPage)
            let urlRequest = NSURLRequest(url: myURL! as URL)
            //pass the request and load the url to the web view controller
            webView.loadRequest(urlRequest as URLRequest)
            // Do any additional setup after loading the view.
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
