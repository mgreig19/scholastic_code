//
//  Faculty.swift
//  GreigCSCIFacultyDirectory
//
//  Created by Mason Greig on 4/08/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//
import Foundation
import UIKit

class Faculty: NSObject {
    
    //creates a Faculty class with variables to hold the different values stored in the PropertyList
    var Image:String!
    var Image_cell:String!
    var name:String!
    var title:String!
    var degree:String!
    var webSite:String!
    var e_mail:String!
    
    //initialize the values of Faculty to the passed in variables indicated below
    init(Image: String, Image_cell: String, name: String, title: String, degree: String, webSite: String, e_mail: String){
        self.Image = Image
        self.Image_cell = Image_cell
        self.name = name
        self.title = title
        self.degree = degree
        self.webSite = webSite
        self.e_mail = e_mail
    }
}
