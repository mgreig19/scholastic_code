//
//  TableTableViewController.swift
//  GreigCSCIFacultyDirectory

//  This application is meant to be a computer science faculty directory. Each row can be selected with the associated instructors information being displayed in the DetailViewController. The user has the capability to e-mail the instructor directly and to visit the faculties web page/ if the faculty doesn't have a page or picture then default properties are displayed. The faculty hours and ta hours are also available for reference
//
//  Created by Mason Greig on 4/10/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit

//allows for the searchController to search through the TableViewController items and filter them based on the search text entry in the searchController
extension TableViewController: UISearchResultsUpdating {
    @available(iOS 8.0, *)
    
    func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchText: searchController.searchBar.text!)
    }
}

//The view which holds the plist information to be displayed
class TableViewController: UITableViewController {
    
    //create the searchController object and set it default to nil
    let searchController = UISearchController(searchResultsController: nil)
    
    //create a faculty object
    var facultyObject = [Faculty]()
    var filteredFaculty = [Faculty]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //read in plist info
        readFacultyList()
        
        //sets up the searchController with necessary attributes
        searchController.searchResultsUpdater = self as? UISearchResultsUpdating
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    //This method reads in the informtion from the plist and appends it to the facultyObject
    func readFacultyList(){
        let path = Bundle.main.path(forResource: "Faculty_List", ofType: "plist")!
        let facultyArray:NSArray = NSArray(contentsOfFile: path)!
        
        for dictionary in facultyArray{
            let facultyName = (dictionary as AnyObject)["name"] as? String
            let facultyTitle = (dictionary as AnyObject)["title"] as? String
            let facultyEmail = (dictionary as AnyObject)["e-mail"] as? String
            let facultyPage = (dictionary as AnyObject)["webpage"] as? String
            let facultyDegree = (dictionary as AnyObject)["degree"] as? String
            let facultyImage = (dictionary as AnyObject)["Image"] as? String
            let facultyImage_cell = (dictionary as AnyObject)["Image_cell"] as? String
            
            facultyObject.append(Faculty(Image: facultyImage!, Image_cell: facultyImage_cell!, name: facultyName!, title: facultyTitle!, degree: facultyDegree!, webSite: facultyPage!, e_mail: facultyEmail!))
            
        }
        
        tableView.reloadData()  //reloads the tableView
    }
    
    // This function dismisses the keyboard when the user taps outside the keyboard surface
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    // This function dismisses the keyboard when the user presses the Return key on the keyboard
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        //UITextField.resignFirstResponder()
        self.view.endEditing(true)
        return true
    }
    
    //filters the TableViewController by using the searchController text being entered
    func filterContentForSearchText(searchText: String, scope: String = "All") {
        filteredFaculty = facultyObject.filter { dictionary in
            return dictionary.name.lowercased().contains(searchText.lowercased())
        }
        
        tableView.reloadData()  //reload tableView to disply the search results
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    //This functions determines which tableViewdata to be displayed based on whether or not a search has been made
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (searchController.isActive && searchController.searchBar.text != "") {
            return filteredFaculty.count
        }
        // #warning Incomplete implementation, return the number of rows
        return facultyObject.count
    }

    //This method assigns information from the plist to each created cell of the TableViewController
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "CELL") as! TableViewCell
        var faculty:Faculty = facultyObject[indexPath.row]
        //if the search is active then initialize the variable faculty to the filtered list of faculty
        if (searchController.isActive && searchController.searchBar.text != "") {
            faculty = filteredFaculty[indexPath.row]
        }
        
        //initialize the cell elements with the information of the correct faculty object
        let imageCell = UIImage(named: faculty.Image_cell)
        cell.cellImage.image = imageCell
        cell.cellTitle.text = faculty.name
        cell.cellSubTitle.text = faculty.title
        
        // Configure the cell...

        return cell
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //pass the necessary information to the AboutViewController in order to have a navigation title
        if (segue.identifier == "About"){
            let destVC = segue.destination
            destVC.navigationItem.title = "About App"
        }
        if (segue.identifier == "Detail"){
            //passing information to the detailviewController to be used to populate the view
            let destVC = segue.destination as! DetailViewController
            if let indexPath = self.tableView.indexPathForSelectedRow{
                //create faculty object
                var faculty:Faculty = facultyObject[indexPath.row]
                if (searchController.isActive && searchController.searchBar.text != "") {
                    faculty = filteredFaculty[indexPath.row]
                }
                //send information from the plist cell into the detail veiw controller
                destVC.navigationItem.title = "Faculty Details"
                destVC.sentName = faculty.name
                destVC.sentImage = faculty.Image
                destVC.sentTitle = faculty.title
                destVC.sentDegree = faculty.degree
                destVC.sentWebSite = faculty.webSite
                destVC.sentEmail = faculty.e_mail
            }
        }
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}

