//
//  AuthorViewController.swift
//  GreigCSCIFacultyDirectory
//
//  Created by Mason Greig on 4/08/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit
//shows my author webpage 
class AuthorViewController: UIViewController {

    @IBOutlet weak var authorWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
            //sets variables to the included html files in the project and NSData objects of the file
            let path = Bundle.main.path(forResource: "/index2", ofType: "html")!
            let data: NSData = NSData(contentsOfFile: path)!
            let html = NSString(data: data as Data, encoding: String.Encoding.utf8.rawValue)
            // Do any additional setup after loading the view.
        
            //load the html files to the webview in the viewcontroller
            authorWebView.loadHTMLString(html! as String, baseURL: Bundle.main.bundleURL)
            // Do any additional setup after loading the view.
        }
    
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }

        // Do any additional setup after loading the view.
    }
