//
//  DetailViewController.swift
//  GreigCSCIFacultyDirectory
//
//  Created by Mason Greig on 4/10/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit
import MessageUI

//this holds the information required for the contents of the detail view module
class DetailViewController: UIViewController, MFMailComposeViewControllerDelegate{
    //variables to hold the passed in variables from the tableViewController in reference to the chosen faculty member
    var sentImage:String!
    var sentName:String!
    var sentTitle:String!
    var sentDegree:String!
    var sentEmail:String!
    var sentWebSite:String!
    
    //Mark outlets for the detail view elements
    @IBOutlet weak var facultyImage: UIImageView!
    @IBOutlet weak var facultyName: UILabel!
    @IBOutlet weak var facultyTitle: UILabel!
    @IBOutlet weak var facultyDegree: UILabel!
    @IBOutlet weak var facultyEmail: UILabel!
    
    //a method to handle the e-mailing of a professor
    @IBAction func contactFaculty(_ sender: Any) {
        // Create a mail composer using the MFMailComposeViewController class
        // and assign it as a delegate
        let sendMessageVC = MFMailComposeViewController()
        sendMessageVC.mailComposeDelegate = self
        
        //Set the destination email and the general information to start the feedback message
        let toSelf = ["\(sentEmail)"]
        let emailSubject = "Schedule a Meeting"
        let messageSummary = "I am interested in scheduling a meeting with you, please contact me at your earliest convience."
        
        //pass the values into the mail object where they are to be populated
        sendMessageVC.setToRecipients(toSelf)
        sendMessageVC.setSubject(emailSubject)
        sendMessageVC.setMessageBody(messageSummary, isHTML: false)
        
        // If MFMailComposer can send mail, then present the populated
        // mail composer view controller.
        if MFMailComposeViewController.canSendMail() {
            self.present(sendMessageVC, animated: true, completion: nil)
        }
    }
    // This is the MFMailComposerViewController delegate method.
    // When it finishes sending mail, dismiss the view controller.
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        self.dismiss(animated: true, completion: nil)
    }
    //populates the detailViewController with the information from the plist section selected in the previous view controller
    override func viewDidLoad() {
        super.viewDidLoad()
        facultyImage.image = UIImage(named: sentImage)
        facultyName.text = sentName
        facultyTitle.text = sentTitle
        facultyDegree.text = sentDegree
        facultyEmail.text = sentEmail
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    //MARK: - Navigation

     //In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //pass the necessary informaiton to the WebViewController to load the faculty webpage
        if (segue.identifier == "Web"){
            let destURLVC = segue.destination as! WebViewController
            destURLVC.navigationItem.title = "Faculty Webpage"
            destURLVC.openWebPage = sentWebSite
        }
        //loads faculty hours in webview controller
        if (segue.identifier == "Hours"){
            let destURLVC = segue.destination as! ResourceViewController
            destURLVC.navigationItem.title = "Faculty Hours"
            destURLVC.openWebPage = "http://www.cs.niu.edu/faculty/facultyhours.shtml"
        }
        //loads ta hours in webview controller
        if (segue.identifier == "TAHelp"){
            let destURLVC = segue.destination as! ResourceViewController
            destURLVC.navigationItem.title = "TA Help Hours"
            destURLVC.openWebPage = "http://www.cs.niu.edu/faculty/tahours.shtml"
        }
     }
}

