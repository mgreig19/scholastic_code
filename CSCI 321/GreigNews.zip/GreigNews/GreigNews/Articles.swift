//
//  Articles.swift
//  GreigNews
//
//  Created by Mason Greig on 4/7/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//
import Foundation
import UIKit

class Articles: NSObject {
    
    var articleTitle:String!
    var articleDesc:String!
    var articleAuthor:String!
    var articleURL:String!
    
    init(articleTitle: String, articleDesc: String, articleAuthor: String, articleURL: String){
        self.articleTitle = articleTitle
        self.articleDesc = articleDesc
        self.articleAuthor = articleAuthor
        self.articleURL = articleURL
    }

}
