//  ViewController.swift
//  GreigNews
//  
//  Program Use: Fetches live information from the fox news site to be displayed within a tableview and have the articles displayed in a web view when a article is selected from the the table view
//
//  Created by Mason Greig on 4/5/17.
//  Copyright © 2017 Mason Greig. All rights reserved.

import UIKit

class ViewController: UIViewController {

    
    func fetchJsonData(){
        //This url contains my api key that was created
        let api_url = URL(string:"https://newsapi.org/v1/articles?source=fox-sports&sortBy=latest&apiKey=c24e6b48508d4d379c649d35b1a5c32d")
        
        // Create a URL request with the API address
        let urlRequest = URLRequest(url: api_url!)
        
        // Submit a request to get the JSON data
        let task = URLSession.shared.dataTask(with: urlRequest) {
            (data,response,error) in
            // if there is an error, print the error and do not continue
            if error != nil {
                print(error!)
                return
            } // end if
            
            // if there is no error, fetch the json formatted content
            if let content = data {
                do {
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: content, options:
                            JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    if let articles = jsonObject["articles"] as? [[String:AnyObject]]{
                        for item in articles{
                            if let title = item["title"] as? String, let author = item["author"] as? String, let description = item["description"] as? String, let url = item["url"] as? String, let urlToImage = item["urlToImage"] as? String{
                                print("*****Begin****")
                                print(title, author, description, url, urlToImage)
                                print("******End*****")
                            }
                        }
                    }
                    
                    // WRITE CODE TO FETCH ONLY THE ARTICLES
                    // Print the attributes of each article in the console first.
                    // AFTER THAT, DESIGN A VIEW TO POPULATE THE FETCHED DATA
                } // end do
                catch {
                    print(error)
                } // end catch
            } // end if
        } // end getDataSession
        task.resume()
    } // end readJsonData function
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchJsonData()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

