//  TableViewController.swift
//  GreigNews

//  App description: This app pulls information from a api as json data and passes the information into the viewcontroller to be displayed in a table view and then displays the article page of the cell that has been selected

//  Created by Mason Greig on 4/6/17.
//  Copyright © 2017 Mason Greig. All rights reserved.


import UIKit

class TableViewController: UITableViewController {
    
    var articlesObject = [Articles]()
    
    func fetchJsonData(){
        //This url contains my api key that was created
        let api_url = URL(string:"https://newsapi.org/v1/articles?source=fox-sports&sortBy=latest&apiKey=c24e6b48508d4d379c649d35b1a5c32d")
        
        // Create a URL request with the API address
        let urlRequest = URLRequest(url: api_url!)
        
        // Submit a request to get the JSON data
        let task = URLSession.shared.dataTask(with: urlRequest) {
            (data,response,error) in
            // if there is an error, print the error and do not continue
            if error != nil {
                print(error!)
                return
            } // end if
            
            // if there is no error, fetch the json formatted content
            if let content = data {
                do {
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: content, options:
                            JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    if let articles = jsonObject["articles"] as? [[String:AnyObject]]{
                        for item in articles{
                            
                            if let title = item["title"] as? String, let author = item["author"] as? String, let description = item["description"] as? String, let url = item["url"] as? String{
                                //puts the json info into a article object
                                self.articlesObject.append(Articles(articleTitle: title, articleDesc: description, articleAuthor: author, articleURL: url))
                            }
                            
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    
                    // WRITE CODE TO FETCH ONLY THE ARTICLES
                    // Print the attributes of each article in the console first.
                    // AFTER THAT, DESIGN A VIEW TO POPULATE THE FETCHED DATA
                } // end do
                catch {
                    print(error)
                } // end catch
            } // end if
        } // end getDataSession
        task.resume()
    } // end readJsonData function

    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchJsonData()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.articlesObject.count
    }
    
    override func tableView(_ tableview: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        //sets an object to the current cell and row of the table view
        let article:Articles = articlesObject[indexPath.row]
        
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "CELL") as! TableViewCell
        //assigns the value of the article object to the objects on the main storyboard table view cell
        cell.cellTitle.text = article.articleTitle
        cell.cellDesc.text = article.articleDesc
        cell.cellAuthor.text = article.articleAuthor
        
        return cell
    }
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //prepares the object url to be passed to the webview controller
        if(segue.identifier == "WEB"){
        let webVC = segue.destination as! WebViewController
            if let indexPath = self.tableView.indexPathForSelectedRow{
                let article:Articles = articlesObject[indexPath.row]
                
                webVC.openWebPage = article.articleURL
            }
        
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        }
    }

}
