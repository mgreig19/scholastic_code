//
//  DetailViewController.swift
//  Greig iOS Final
//
//  Created by Admin on 5/10/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class DetailViewController: UIViewController, CLLocationManagerDelegate {

    var sentCity:String!
    var sentStreet:String!
    var sentzipCity:String!
    var sentHours1:String!
    var sentHours2:String!
    var sentPhone:String!
    var sentWebSite:String!
    var sentLatitude:String!
    var sentLongitude:String!
    
    @IBOutlet weak var address: UITextView!
    @IBOutlet weak var hours: UITextView!
    @IBOutlet weak var webURL: UILabel!
    @IBOutlet weak var phoneNum: UILabel!
    @IBOutlet weak var mapView: MKMapView!
    
   /* @IBAction func mapType(_ sender: Any) {
        let segIndex = (sender as AnyObject).selectedSegmentIndex
        switch segIndex {
        case 0?:
            mapView.mapType = MKMapType.standard
        case 1?:
            mapView.mapType = MKMapType.satellite
        case 2?:
            mapView.mapType = MKMapType.hybrid
        default:
            break
        }
    }*/
    
    @IBAction func getDirections(_ sender: Any) {
        UIApplication.shared.openURL(URL(string: "http://maps.apple.com/maps?daddr=\(sentLatitude!),\(sentLongitude!)")!)
    }
    
    
    @IBAction func callBuisness(_ sender: UIButton) {
        let myURL:NSURL = URL(string: "tel://\(sentPhone!)")! as NSURL
        UIApplication.shared.open(myURL as URL, options: [:], completionHandler: nil)
        
        // Display the simple alert since we cannot test the above
        // code on the simulator
        let alertController = UIAlertController(title: "Calling..", message: "1-\(sentPhone!)", preferredStyle: .alert)
        
        let dismissButton = UIAlertAction(title: "Dismiss", style: .cancel, handler: {
            
            (alert: UIAlertAction!) -> Void in
        })
        alertController.addAction(dismissButton)
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        address.text = sentStreet
        address.text.append("\n")
        address.text.append(sentCity)
        address.text.append(" ")
        address.text.append(sentzipCity)
        
        hours.text = sentHours1
        hours.text.append("\n")
        hours.text.append(sentHours2)
        
        webURL.text =  sentWebSite
        phoneNum.text = sentPhone
        
        
        
        let pinLocation: CLLocationCoordinate2D = CLLocationCoordinate2DMake(CLLocationDegrees(sentLatitude)!, CLLocationDegrees(sentLongitude)!)
        
        let span = MKCoordinateSpanMake(1, 1)
        
        let region = MKCoordinateRegion(center: pinLocation, span: span)
        
        mapView.setRegion(region, animated: true)
        
        let objAnnimation = MKPointAnnotation()
        objAnnimation.coordinate = pinLocation
        objAnnimation.title = "Greig's Pizzaria"
        objAnnimation.subtitle = "Best fake pizza in town!"
        self.mapView.addAnnotation(objAnnimation)
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //pass the necessary informaiton to the WebViewController to load the faculty webpage
        if (segue.identifier == "Web"){
            let destURLVC = segue.destination as! WebViewController
            destURLVC.navigationItem.title = sentCity
            destURLVC.navigationItem.title?.append(" Store Website")
            destURLVC.openWebPage = sentWebSite
        }
        //loads faculty hours in webview controller
        /*if (segue.identifier == "Map"){
         let destMapVC = segue.destination as! MapViewController
         destMapVC.navigationItem.title = "Directions to \(sentCity)"
         destMapVC.storeLatitude = sentLatitude
         destMapVC.storeLongitude = sentLongitude
         }*/
    }

}
