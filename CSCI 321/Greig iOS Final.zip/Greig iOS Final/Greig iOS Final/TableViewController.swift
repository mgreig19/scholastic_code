//
//  TableViewController.swift
//  Greig iOS Final
//
//  Created by Admin on 5/10/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit

//allows for the searchController to search through the TableViewController items and filter them based on the search text entry in the searchController
/*extension TableViewController: UISearchResultsUpdating {
 @available(iOS 8.0, *)
 
 func updateSearchResults(for searchController: UISearchController) {
 filterContentForSearchText(searchText: searchController.searchBar.text!)
 }
 }*/

class TableViewController: UITableViewController {
    //create the searchController object and set it default to nil
    // let searchController = UISearchController(searchResultsController: nil)
    
    //create a faculty object
    var businessObject = [Business]()
    //var filteredBusiness = [Business]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //read in plist info
        readBusinessList()
        
        /*//sets up the searchController with necessary attributes
         searchController.searchResultsUpdater = self as? UISearchResultsUpdating
         searchController.dimsBackgroundDuringPresentation = false
         definesPresentationContext = true
         tableView.tableHeaderView = searchController.searchBar
         */
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    //This method reads in the informtion from the plist and appends it to the facultyObject
    func readBusinessList(){
        let path = Bundle.main.path(forResource: "Locations", ofType: "plist")!
        let businessArray:NSArray = NSArray(contentsOfFile: path)!
        
        for dictionary in businessArray{
            let city = (dictionary as AnyObject)["city"] as? String
            let street = (dictionary as AnyObject)["street"] as? String
            let stateZip = (dictionary as AnyObject)["state_zip"] as? String
            let phoneNum = (dictionary as AnyObject)["phone"] as? String
            let businessPage = (dictionary as AnyObject)["website"] as? String
            let weekDayHours = (dictionary as AnyObject)["hours_1"] as? String
            let weekEndHours = (dictionary as AnyObject)["hours_2"] as? String
            let latitudeNum = (dictionary as AnyObject)["latitude"] as? String
            let longitudeNum = (dictionary as AnyObject)["longitude"] as? String
            let businessLogo = (dictionary as AnyObject)["logo"] as? String
            
            businessObject.append(Business(cityName: city!, addressStreet: street!, zipCity: stateZip!, phone: phoneNum!, webSite: businessPage!, hours_1: weekDayHours!, hours_2: weekEndHours!, latitude: latitudeNum!, longitude: longitudeNum!, logoImage: businessLogo!))
            
        }
        
        tableView.reloadData()  //reloads the tableView
    }
    
    // This function dismisses the keyboard when the user taps outside the keyboard surface
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    // This function dismisses the keyboard when the user presses the Return key on the keyboard
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        //UITextField.resignFirstResponder()
        self.view.endEditing(true)
        return true
    }
    
    //filters the TableViewController by using the searchController text being entered
    /*func filterContentForSearchText(searchText: String, scope: String = "All") {
     filteredBusiness = businessObject.filter { dictionary in
     return dictionary.cityName.lowercased().contains(searchText.lowercased())
     }
     
     tableView.reloadData()  //reload tableView to disply the search results
     }*/
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    //This functions determines which tableViewdata to be displayed based on whether or not a search has been made
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        /*if (searchController.isActive && searchController.searchBar.text != "") {
         return filteredBusiness.count
         }*/
        // #warning Incomplete implementation, return the number of rows
        return businessObject.count
    }
    
    //This method assigns information from the plist to each created cell of the TableViewController
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "CELL") as! TableViewCell
        let business:Business = businessObject[indexPath.row]
        //if the search is active then initialize the variable faculty to the filtered list of faculty
        /*if (searchController.isActive && searchController.searchBar.text != "") {
         business = filteredBusiness[indexPath.row]
         }*/
        
        //initialize the cell elements with the information of the correct faculty object
        //let imageCell = UIImage(named: business.logoImage)
        //cell.cellImage.image = imageCell
        cell.cellTitle.text = business.cityName
        cell.cellSubtitle.text = business.addressStreet
        
        // Configure the cell...
        
        return cell
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "Detail"){
            //passing information to the detailviewController to be used to populate the view
            let destVC = segue.destination as! DetailViewController
            if let indexPath = self.tableView.indexPathForSelectedRow{
                //create faculty object
                let business:Business = businessObject[indexPath.row]
                /*if (searchController.isActive && searchController.searchBar.text != "") {
                 business = filteredBusiness[indexPath.row]
                 }*/
                //send information from the plist cell into the detail veiw controller
                destVC.navigationItem.title = business.cityName
                destVC.navigationItem.title?.append(" Store Details")
                destVC.sentCity = business.cityName
                destVC.sentStreet = business.addressStreet
                destVC.sentzipCity = business.zipCity
                destVC.sentPhone = business.phone
                destVC.sentWebSite = business.webSite
                destVC.sentHours1 = business.hours_1
                destVC.sentHours2 = business.hours_2
                destVC.sentLatitude = business.latitude
                destVC.sentLongitude = business.longitude
            }
        }
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }

}
