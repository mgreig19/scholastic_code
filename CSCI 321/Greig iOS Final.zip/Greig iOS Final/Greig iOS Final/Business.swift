//
//  Business.swift
//  Greig iOS Final
//
//  Created by Admin on 5/10/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import Foundation
import UIKit

class Business: NSObject {
    //creates a Faculty class with variables to hold the different values stored in the PropertyList
    
    var cityName:String!
    var addressStreet:String!
    var zipCity:String!
    var phone:String!
    var webSite:String!
    var hours_1:String!
    var hours_2:String!
    var latitude:String!
    var longitude:String!
    var logoImage:String!
    
    
    //initialize the values of Faculty to the passed in variables indicated below
    init(cityName: String, addressStreet: String, zipCity: String, phone: String, webSite: String, hours_1: String, hours_2: String, latitude: String, longitude: String, logoImage: String){
        
        self.cityName = cityName
        self.addressStreet = addressStreet
        self.zipCity = zipCity
        self.phone = phone
        self.webSite = webSite
        self.hours_1 = hours_1
        self.hours_2 = hours_2
        self.latitude = latitude
        self.longitude = longitude
        self.logoImage = logoImage
    }

}
