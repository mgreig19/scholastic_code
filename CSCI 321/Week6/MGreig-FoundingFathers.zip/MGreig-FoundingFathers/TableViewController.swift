//
//  TableViewController.swift
//  MGreig-FoundingFathers
//
//  Created by Mason Greig on 2/22/17.
//  Copyright © 2017 Adminvjvndl. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    var presidentObject = [President]() //Initializes an object of class (President)

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //read in plist
        readPropertyList()

    }
    //This function finds the property list, read each dictionary entries (properties)
    // in the plist arrray, and append initalize the object protperies in the President class.
    func readPropertyList() {
        let path = NSBundle.mainBundle().pathForResource("PropertyList", ofType: "plist")!
        let presidentArray:NSArray = NSArray(contentsOfFile:path)!
        
        for dictionary in presidentArray {
            let number = dictionary["Number"] as! Int
            let president_name = dictionary["Name"] as! String
            let president_title = dictionary["Title"] as! String
            let spouse = dictionary["Spouse"] as! String
            let office_years = dictionary["Years"] as! String
            let political_party = dictionary["Party"] as! String
            let cell_image = dictionary["Image-cell"] as! String
            let president_image = dictionary["Image"] as! String
            
            presidentObject.append(President(positionNumber: number, name: president_name, title: president_title, presidentSpouse: spouse, years: office_years, party: political_party, cellImage: cell_image, presidentImage: president_image))
            
        }
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        //returns the value of 1 = 1 section created
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return presidentObject.count    //the number of rows is equal to the size of the array within the dictionary
    }

    //sets the view for the table to a president object for each row
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let president:President = presidentObject[indexPath.row]
        
        
        let cell:TableViewCell = tableView.dequeueReusableCellWithIdentifier("CELL") as! TableViewCell
        
        // Place cell image, president name, and years in office in the table cell
        let cellImageName = UIImage(named: president.cellImage)
        cell.cellImageView.image = cellImageName
        cell.cellTitleLabel.text = president.name
        cell.cellSubTitleLabel.text = president.years
        
        return cell
    }
    

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        //if the segue is DetailView then let destVC equal the detailview controller
        if (segue.identifier == "DetailView") {
            let destVC = segue.destinationViewController as! DetailViewController
            
            // Prepare to send data to the DetailViewController
            if let indexPath = self.tableView
                .indexPathForSelectedRow {
                
                //create president object
                let president:President = presidentObject[indexPath.row]
                
                //send information from the plist cell into the detail veiw controller
                destVC.navigationItem.title = president.name
                destVC.sentImage = president.presidentImage
                destVC.sentTitle = president.title
                destVC.sentParty = president.party
                destVC.sentSpouse = president.presidentSpouse
            }
        }
    }


}


    


