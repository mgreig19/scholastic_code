//
//  AuthorViewController.swift
//  MGreig-FoundingFathers
//
//  Created by Admin on 2/27/17.
//  Copyright © 2017 Adminvjvndl. All rights reserved.
//

import UIKit

class AuthorViewController: UIViewController {

    //Mark outlet
    @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //sets variables to the included html files in the project and NSData objects of the file
        let path = NSBundle.mainBundle().pathForResource("/index2", ofType: "html")!
        let data: NSData = NSData(contentsOfFile: path)!
        let html = NSString(data: data, encoding: NSUTF8StringEncoding)
        // Do any additional setup after loading the view.
       
        //load the html files to the webview in the viewcontroller
        webView.loadHTMLString(html as! String, baseURL: NSBundle.mainBundle().bundleURL)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
