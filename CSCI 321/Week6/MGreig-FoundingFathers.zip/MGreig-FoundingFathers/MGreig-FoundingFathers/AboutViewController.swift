//
//  AboutViewController.swift
//  MGreig-FoundingFathers
//
//  Created by Admin on 2/27/17.
//  Copyright © 2017 Adminvjvndl. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    @IBOutlet weak var aboutTextView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Formats and displays text for information regarding the author, application details, and app version
        let name = "Mason Greig"
        let appDescription = "This app provides a list of the founding fathers and a small amount of information about each founding father to be displayed with a image of the person."
        let version = "Version 1.0"
        
        aboutTextView.text = "Author: \(name)\n\nAbout App: \n\n\(appDescription)\n\n\(version)"

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
