//
//  TableViewCell.swift
//  MGreig-FoundingFathers
//
//  Created by Admin on 2/27/17.
//  Copyright © 2017 Adminvjvndl. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    //outlets for the image, title, and subtitle of the prototype cell
    @IBOutlet weak var cellImageView: UIImageView!
    @IBOutlet weak var cellTitleLabel: UILabel!
    @IBOutlet weak var cellSubTitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
