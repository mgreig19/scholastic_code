//
//  President.swift
//  MGreig-FoundingFathers
//
//  Created by Admin on 2/27/17.
//  Copyright © 2017 Adminvjvndl. All rights reserved.
//

import UIKit
import Foundation


//creates a president class with variables to hold the different values stored in the PropertyList
class President: NSObject {
    var positionNumber:Int
    var name:String!
    var title:String!
    var presidentSpouse:String!
    var years:String!
    var party:String!
    var cellImage:String!
    var presidentImage:String!
    
    //initialises the president class to the values stored in the propertyList
    init(positionNumber: Int, name: String, title: String, presidentSpouse: String, years: String, party: String, cellImage: String, presidentImage: String) {
        self.positionNumber = positionNumber
        self.name = name
        self.title = title
        self.presidentSpouse = presidentSpouse
        self.years = years
        self.party = party
        self.cellImage = cellImage
        self.presidentImage = presidentImage
        }

}
