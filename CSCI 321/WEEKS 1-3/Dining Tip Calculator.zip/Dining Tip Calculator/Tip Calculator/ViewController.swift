//
//  ViewController.swift
//  Tip Calculator
//
//  Created by Mason Greig on 2/1/17.
//  Copyright © 2017 NIU Computer Science 321. All rights reserved.
//

import UIKit
import Foundation //allows for the use of the round() function implemented to allow for readable decimals

class ViewController: UIViewController, UITextFieldDelegate {
    
    //Initializes the default value of the groupSize label display to 1
    var minPeople = 1.0
    
    //Mark outlets
    @IBOutlet weak var serviceCost: UITextField!
    @IBOutlet weak var tipAmount: UILabel!
    @IBOutlet weak var totalAmount: UILabel!
    @IBOutlet weak var eachBill: UILabel!
    @IBOutlet weak var groupSize: UILabel!
    
    //Mark-IBActions
    //This button takes the users selection and passes the appropiate 
    //tip decimal (represents the tip percentage) into the prepareResuls()
    //function to be added to the bill amount and then calls the showResults() method to show the results of the calculations
    @IBAction func serviceQuality(sender: UIButton) {
        let preform = sender.currentTitle!
        if (preform == "Poor"){
            prepareResults(0.10)
        }
        else if (preform == "Ok"){
            prepareResults(0.18)
        }
        else if (preform == "Good"){
            prepareResults(0.20)
        }
        else if (preform == "Great"){
            prepareResults(0.22)
        }
        else if (preform == "Excellent"){
            prepareResults(0.25)
        }
        showResults()
    }
    
    //Initializes the const variable group to the value which is in the stepper and then displays that value in the groupSize label field as the user increases or decreases their selection; minimum value is 1; stepper goes up and down by one
    @IBAction func groupSize(sender: UIStepper) {
        let group = Int(sender.value)
        groupSize.text = ("\(group)")
    }

    //Mark: Delegate methods
    
    //This function unhides the labels which hold the results of the tip/total/eachBill calculations
    func showResults(){
        tipAmount.hidden = false
        totalAmount.hidden = false
        eachBill.hidden = false
        }
    
    //This function also calculates the tip amount to be added to the bill
    //and displays the tip amount and total amounts in their
    //respective label fields
    func prepareResults(earnedTip: Double){
        //If the textfield is not nil, convert the value entered
        //in the textfield to a double and assign it to
        //a constant named entered amount
        if let enteredAmount = Double(serviceCost.text!){
            //calculate tip amount based on the amount of the bill then display the tip amount in the tipAmount label field
            let tipGiven = round((enteredAmount * earnedTip) * 100) / 100
            tipAmount.text = ("Tip Amount (\(earnedTip * 100)%) = $\(tipGiven)")
            
            //add tip amount to the enteredAmount and display the total amount due in the totalAmount label field
            let total = round((enteredAmount + tipGiven) * 100) / 100
            totalAmount.text = ("Total Amount: $\(total)")
            
            //calculates the amount each person's bill and displays the result in the eachBill label field
            let splitBill = round((total / Double(groupSize.text!)!) * 100) / 100
            eachBill.text = ("Amount Per Person: $\(splitBill)")
        }
    }
    
    //This function dismisses thwe keyboard when the user presses the return key
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        serviceCost.resignFirstResponder()
        return true
    }
    
    //This function dismisses the key board when
    //the user taps outside the view surface
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }
    
    //keeps the results labels hidden until a showResults() method is called to display the results of the tip calculations
    override func viewDidLoad() {
        super.viewDidLoad()
        eachBill.hidden = true
        tipAmount.hidden = true
        totalAmount.hidden = true
        groupSize.text = "\(minPeople)"
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

