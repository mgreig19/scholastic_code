//
//  ViewController.swift
//  Welcome
//
//  Created by Mason Greig on 1/20/17.
//  Copyright © 2017 NIU Computer Science 321. All rights reserved.
//
/*
 Author Mason Greig
 
 This is my first app for CSCI 321/521
 
 I learned to create outlets for the label and image view
 
 I learned to add two buttons which take input from the sender when touched inside
 
 I learned add a textfield which displays a message welcoming either the undergraduate or graduate class, depending on the button clicked
 
 I learned to add photos to a display view. Different photos get displayed depending on the button which is clicked
 
 I learned to add a new view/second screen for the app, which is accessed through a info light button to display the author information and picture
*/
import UIKit

class ViewController: UIViewController {
    
    //Mark outlets
    @IBOutlet weak var displayMsg: UILabel!
    @IBOutlet weak var classImageView: UIImageView!
    
    //Mark actions
    @IBAction func touchNumber(sender: UIButton) {
        //properties
        let buttonNum = sender.currentTitle!
        
        //decision statement which determines which message and photo to display
        if(buttonNum == "321"){
            displayMsg.text = "Welcome iOS \(buttonNum) undergraduate students!🤓"
            
            //Display undergrad class image
            classImageView.image = UIImage (named: "image_CSCI321_1")
        }
        else if (buttonNum == "521"){
            displayMsg.text = "Welcome iOS \(buttonNum) graduate students!🤔"
            
            //Display grad class image
            classImageView.image = UIImage (named: "image_CSCI521_1")
        }
        
    }
    

}

