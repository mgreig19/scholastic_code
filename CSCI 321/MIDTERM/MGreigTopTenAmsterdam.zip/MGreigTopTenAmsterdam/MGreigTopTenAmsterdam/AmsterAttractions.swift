//
//  AmsterAttractions.swift
//  MGreigTopTenAmsterdam
//
//  Created by Admin on 3/7/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import Foundation
import UIKit

class AmsterAttractions: NSObject {

    //creates a AmsterAttractions class with variables to hold the different values stored in the PropertyList
    var type:String!
    var name:String!
    var hours:String!
    var describe:String!
    var address:String!
    var phoneNumber:String!
    var webSite:String!
    var cellImage:String!
    var venueImage:String!
    var latitude:String!
    var longitude:String!
    
    //initialises the AmsterAttractions class to the values stored in the propertyList
    init(type: String, name: String, hours: String, describe: String, address: String, phoneNumber: String, webSite: String, cellImage: String, venueImage: String, latitude: String, longitude: String) {
        self.type = type
        self.name = name
        self.hours = hours
        self.describe = describe
        self.address = address
        self.phoneNumber = phoneNumber
        self.webSite = webSite
        self.cellImage = cellImage
        self.venueImage = venueImage
        self.latitude = latitude
        self.longitude = longitude
        }
    
}
