//
//  TableViewController.swift
//  MGreigTopTenAmsterdam
//
//  Created by Admin on 3/7/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    //create a object of type AmsterAttractions class
    var attractionsObject = [AmsterAttractions]() //initializes an object of AmsterAttractions class

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //read in plist information
        readAttractionsList()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    //This function finds the property list, read each dictionary entries (properties)
    // in the plist arrray, and append initalize the object protperies in the AmsterAttractions class.
    func readAttractionsList(){
        let path = NSBundle.mainBundle().pathForResource("AttractionsList", ofType: "plist")!
        let attractionsArray:NSArray = NSArray(contentsOfFile: path)!
        
        for dictionary in attractionsArray{
            let venueType = dictionary["Type"] as! String
            let venueName = dictionary["Name"] as! String
            let venueHours = dictionary["Hours"] as! String
            let venueAddress = dictionary["Address"] as! String
            let describeVenue = dictionary["Description"] as! String
            let phoneNum = dictionary["Phone Number"] as! String
            let venueWebSite = dictionary["Website"] as! String
            let cell_Image = dictionary["Image-cell"] as! String
            let image = dictionary["Image"] as! String
            let aproxLatitude = dictionary["latitude"] as! String
            let aproxLongitude = dictionary["longitude"] as! String
            
            attractionsObject.append(AmsterAttractions(type: venueType, name: venueName, hours: venueHours, describe: describeVenue, address: venueAddress, phoneNumber: phoneNum, webSite: venueWebSite, cellImage: cell_Image, venueImage: image, latitude: aproxLatitude, longitude: aproxLongitude))
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return attractionsObject.count
    }

    //sets the view for the table to a president object for each row
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let attractions:AmsterAttractions = attractionsObject[indexPath.row]
        let cell:TableViewCell = tableView.dequeueReusableCellWithIdentifier("CELL") as! TableViewCell
        
        let cellImageName = UIImage(named: attractions.cellImage)
        cell.attractionImage.image = cellImageName
        cell.attractionTitle.text = attractions.name
        cell.subTitle.text = attractions.type
        
        // Configure the cell...

        return cell
    }
    /*
    override func viewWillAppear(animated: Bool) {
        
        imageView.contentMode = .ScaleAspectFit
    }
    override func viewDidAppear(animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.collapsed
        super.viewWillAppear(animated)
        
        let backgroundImage = UIImage(named: "FinFlag.jpg")
        let imageView = UIImageView(image: backgroundImage)
        self.tableView.backgroundView = imageView
        }
    */
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        //if the segue is DetailView then let destVC equal the detailview controller
        if (segue.identifier == "DetailView"){
            let destVC = segue.destinationViewController as! DetailViewController
            // Prepare to send data to the DetailViewController
            if let indexPath = self.tableView.indexPathForSelectedRow{
                //create president object
                let attractions:AmsterAttractions = attractionsObject[indexPath.row]
                //send information from the plist cell into the detail veiw controller
                destVC.navigationItem.title = attractions.name
                destVC.sentName = attractions.name
                destVC.sentImage = attractions.venueImage
                destVC.sentDescribe = attractions.describe
                destVC.sentHours = attractions.hours
                destVC.sentPhoneNumber = attractions.phoneNumber
                destVC.sentAddress = attractions.address
                destVC.sentWebSite = attractions.webSite
            }
        }
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}
