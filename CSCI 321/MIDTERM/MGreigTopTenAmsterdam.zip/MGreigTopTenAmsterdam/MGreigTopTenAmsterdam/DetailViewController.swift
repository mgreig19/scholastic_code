//
//  DetailViewController.swift
//  MGreigTopTenAmsterdam
//
//  Created by Admin on 3/7/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    // Prepare variables to hold data sent from the TableViewController
    var sentName:String!
    var sentImage:String!
    var sentDescribe:String!
    var sentHours:String!
    var sentPhoneNumber:String!
    var sentAddress:String!
    var sentWebSite:String!
    
    //Mark outlets
    @IBOutlet weak var venueImage: UIImageView!
    @IBOutlet weak var venueAddress: UILabel!
    @IBOutlet weak var venueHours: UILabel!
    @IBOutlet weak var venuePhoneNum: UILabel!
    @IBOutlet weak var venueDescription: UITextView!
    
    //I tried to add the phone number but it says it is nil when it isn't nil. the value populates in the label just fine so I know it is in the variable but for some reason it is nil for this function
    //Mark action for phone call
    @IBAction func callVenue(sender: UIButton) {
        UIApplication.sharedApplication().openURL(NSURL(string: "tel://\(sentPhoneNumber)")!)
        
        // Display the simple alert since we cannot test the above
        // code on the simulator
        let alertControl = UIAlertController(title: "Calling..", message: "\(sentPhoneNumber)", preferredStyle: .Alert)
        
        let dismiss = UIAlertAction(title: "Dismiss", style: .Cancel, handler: {
            
            (alert: UIAlertAction!) -> Void in
        })
        alertControl.addAction(dismiss)
        self.presentViewController(alertControl, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //set the detail view controller objects to the passed in values from the table view
        venueImage.image = UIImage(named: sentImage)
        venueAddress.text = sentAddress
        venueHours.text = sentHours
        venuePhoneNum.text = sentPhoneNumber
        venueDescription.text = sentDescribe
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "VenueURL"){
            let destURLVC = segue.destinationViewController as! WebView
        
            destURLVC.navigationItem.title = "\(sentName) Website"
            destURLVC.openWebPage = sentWebSite
            }
        }
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
}