//
//  WebView.swift
//  MGreigTopTenAmsterdam
//
//  Created by Admin on 3/7/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit

class WebView: UIViewController {

    //Mark outlet
    @IBOutlet weak var webView: UIWebView!
    
    //create a variable to hold the url passed from the detail view
    var openWebPage:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //assign the url to a NSURL object myURL
        let myURL = NSURL(string: openWebPage)
        let urlRequest = NSURLRequest(URL: myURL!)
        //pass the request and load the url to the web view controller
        webView.loadRequest(urlRequest)
    }
        // Do any additional setup after loading the view.
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
