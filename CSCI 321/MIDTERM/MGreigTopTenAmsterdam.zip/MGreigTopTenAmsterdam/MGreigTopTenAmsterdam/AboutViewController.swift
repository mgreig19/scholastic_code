//
//  AboutViewController.swift
//  MGreigTopTenAmsterdam
//
//  Created by Admin on 3/7/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//
//required libraries
import UIKit
import MessageUI

class AboutViewController: UIViewController, MFMailComposeViewControllerDelegate {
    //Mark outlet
    @IBOutlet weak var aboutTextView: UITextView!
    //Mark action functions
    @IBAction func sendFeedBack(sender: UIButton) {
        
        // Create a mail composer using the MFMailComposeViewController class
        // and assign it as a delegate
        let sendMessageVC = MFMailComposeViewController()
        sendMessageVC.mailComposeDelegate = self
        
        //Set the destination email and the general information to start the feedback message
        let toSelf = ["z1768935@students.niu.edu"]
        let emailSubject = "Top Ten Amsterdam Attractions App Feedback"
        let messageSummary = "Feedback for Amsterdam App, Version 1.0"
        
        //pass the values into the mail object where they are to be populated
        sendMessageVC.setToRecipients(toSelf)
        sendMessageVC.setSubject(emailSubject)
        sendMessageVC.setMessageBody(messageSummary, isHTML: false)
        
        // If MFMailComposer can send mail, then present the populated
        // mail composer view controller.
        if MFMailComposeViewController.canSendMail() {
            self.presentViewController(sendMessageVC, animated: true, completion: nil)
        }
    }
    
    // This is the MFMailComposerViewController delegate method.
    // When it finishes sending mail, dismiss the view controller.
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Formats and displays text for information regarding the author, application details, and app version
        let name = "Mason Greig"
        let appDescription = "This app lists the top ten attractions that every person travelling to Amsterdam, Netherlands should experience. The app provides the following for each venue: a short description, address, phone number, hours of operation, and a option to go to the venue's website. The app also offers the option to call the venue and leave feeback about the app."
        let version = "Version 1.0"
        
        aboutTextView.text = "Author: \(name)\n\nAbout App: \n\n\(appDescription)\n\n\(version)"

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
