//
//  TableViewCell.swift
//  MGreigTopTenAmsterdam
//
//  Created by Admin on 3/7/17.
//  Copyright © 2017 Mason Greig. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    //outlets for the image, title, and subtitle of the prototype cell
    @IBOutlet weak var attractionImage: UIImageView!
    
    @IBOutlet weak var attractionTitle: UILabel!
    
    @IBOutlet weak var subTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
